# Symphony · AI Platform Engineering

Presentación técnica para la evaluación de AI Platform Engineer.

## Correr en local con Docker

```bash
# 1. Clonar / entrar al directorio
cd symphony-platform

# 2. Build de la imagen
docker build -t symphony-platform .

# 3. Correr el contenedor
docker run -p 8080:80 symphony-platform
```

Abrir en el browser: **http://localhost:8080**

Para detener:
```bash
docker stop $(docker ps -q --filter ancestor=symphony-platform)
```

---

## Publicar en GitHub Pages (sin costo, URL pública en minutos)

### Opción A — desde la interfaz de GitHub (más fácil)

1. Subir todos los archivos a tu repositorio
2. Ir a **Settings → Pages**
3. En *Source* seleccionar **Deploy from a branch**
4. Branch: `main` / Folder: `/ (root)`
5. Guardar — en ~2 minutos tendrás una URL: `https://<tu-usuario>.github.io/<nombre-repo>`

### Opción B — con GitHub Actions (automático en cada push)

Crear el archivo `.github/workflows/deploy.yml`:

```yaml
name: Deploy to GitHub Pages

on:
  push:
    branches: [main]

jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Deploy
        uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./
```

---

## Estructura del repositorio

```
symphony-platform/
├── index.html       # Presentación completa (single-file)
├── Dockerfile       # Para correr en local con Docker
└── README.md        # Este archivo
```

---

## Secciones de la presentación

| # | Sección | Contenido |
|---|---------|-----------|
| 01 | Arquitectura | 4 capas de la plataforma + integraciones |
| 02 | Golden Path | 8 pasos del repo al cliente |
| 03 | Decisiones | 3 trade-offs documentados |
| 04 | Observabilidad | SLIs, runbook P1, visibilidad negocio |
| 05 | Visión 12 meses | Roadmap 3 horizontes + KPIs |
